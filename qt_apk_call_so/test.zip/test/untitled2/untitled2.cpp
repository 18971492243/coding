#include "untitled2.h"


Untitled2::Untitled2()
{
}

void Untitled2::showlog()
{
    qDebug()<<"////////////////////////////";
    return;
}
