#ifndef UNTITLED2_H
#define UNTITLED2_H

#include "untitled2_global.h"
#include <QDebug>

class UNTITLED2SHARED_EXPORT Untitled2
{

public:
    Untitled2();
    void showlog();
};

#endif // UNTITLED2_H
