#ifndef CALL_PYTHON_H
#define CALL_PYTHON_H

#include <QObject>
#include <Python.h>
#include <QDebug>

class Call_python : public QObject
{
    Q_OBJECT
public:
    explicit Call_python(QObject *parent = nullptr);

signals:

public slots:
    int call();
};

#endif // CALL_PYTHON_H
