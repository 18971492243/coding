#!/usr/bin/env python
# -*- coding: utf-8 -*-
def hello():
    print("hello world!")

def add(a,b):
	c = a+b;
	print("a+b:",c)

def getValue(a,b)
	c = a+b;
	print("return value:",c)
	return c;