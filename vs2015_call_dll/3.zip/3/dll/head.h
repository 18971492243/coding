#ifndef HEADER_H
#define HEADER_H
#ifdef AFX_CLASS
#define AFX_EX_CLASS _declspec(dllexport)
#else
#define AFX_EX_CLASS _declspec(dllimport)
#endif


class AFX_EX_CLASS cls
{
public:
	cls(int i, int j);
	int add();
private:
	int m;
	int n;
};

#endif