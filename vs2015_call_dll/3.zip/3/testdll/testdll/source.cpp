#define AFX_CLASS
#include "head.h"

cls::cls(int i, int j)
{
	m = i;
	n = j;
}

int cls::add()
{
	return m + n;
}

int cls::getm()
{
	return m;
}

int cls::getn()
{
	return n;
}