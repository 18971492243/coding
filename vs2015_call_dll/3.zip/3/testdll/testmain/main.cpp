#include "../../testdll/testdll/head.h"
#pragma comment(lib,"../../testdll/Debug/testdll.lib")

#include <iostream>
using namespace std;

int main()
{
	cls *clsObj = new cls(2, 3);
	int num = clsObj->add();
	cout << "result = " << num << endl;

	int m = 0,n = 0;
	m = clsObj->getm();
	n = clsObj->getn();

	cout << "m = " << m << endl;
	cout << "n = " << n << endl;

	while (1);
	return 0;
}