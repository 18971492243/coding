#pragma once
__declspec(dllexport) int ADD(int a, int b);