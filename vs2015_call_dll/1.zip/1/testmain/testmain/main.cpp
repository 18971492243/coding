//#include "../../dll/dll.h"
#pragma comment (lib,"../../dll/testdll1.lib")
#include "../../dll/dll.h"
#include <stdio.h>
int main()
{
	int sum = 0;
	sum = ADD(3, 4);
	printf("sum =%d \n", sum);
	while (1);
	return 0;
}