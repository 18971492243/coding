#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QCoreApplication>
#include <Python.h>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    /*****1.C++调用普通函数*****/
    //1.1.python初始化
    Py_Initialize();
    if( !Py_IsInitialized() ){
        qDebug() << "inital error ";
        return 0;
    }
         qDebug() << "inital ok ";

    //1.2.python文件路径
   PyRun_SimpleString("import sys");
   PyRun_SimpleString("sys.path.append('../')");

    //1.3.导入testpython（python）模块文件
    PyObject* pModule = PyImport_ImportModule("sss");
    if (pModule == nullptr)
    {
        qDebug() << "Cant open python file!";
        return -1;
    }

    //1.4.获得python中函数定义
    PyObject* pFunhello= PyObject_GetAttrString(pModule,"hello");
    if(!pFunhello)
    {
        qDebug()<<"Get function hello failed";
        return -1;
    }

    //1.5.调用python函数
    PyObject_CallFunction(pFunhello,nullptr);

    //2.1C++调用带参数函数
    PyObject* pFunc = PyObject_GetAttrString(pModule,"add");
    if(!pFunc){
        qDebug()<<"Get function hello failed";
        return -1;
    }
    //2.2  2个参数
    PyObject* pArgs = PyTuple_New(2);
    //(i,i)的意思  "i"(integer) [int] :将一个C类型的int转换成Python int对象
    pArgs = Py_BuildValue("(i,i)",2,2);
    //2.3  调用python函数
    PyEval_CallObject(pFunc,pArgs);


    //3.13.调用带返回值函数
    PyObject* pFunc1 = PyObject_GetAttrString(pModule,"getValue");
    if(!pFunc1){
        qDebug()<<"Get function hello failed";
        return -1;
    }

    PyObject *pArgs1 = Py_BuildValue("(i,i)",2,2);
    PyObject *pReturn = PyObject_CallObject(pFunc1,pArgs1);

    if(pReturn == nullptr)
    {
        qDebug() << "null return";
        return -1;
    }

    int value= 0;
    PyArg_Parse(pReturn,"i",&value);
    qDebug() << "value = " << value;

    //1.6.python调用结束
    Py_Finalize();
    /*****python调用结束*****/

    return app.exec();
}
